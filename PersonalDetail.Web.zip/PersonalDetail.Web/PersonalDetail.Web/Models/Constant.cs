﻿namespace PersonalDetail.Web.Models
{
    public static class Constant
    {
        public const string ThankYouView = "~/Views/PersonalWeb/ThankYou.cshtml";
        public const string Error = "Unable to process your request, please try again.";
        public const string Filepath = @"C:/Developer/App/PersonalDetail.Web/PersonalDetail.Web/Files/Save.txt";
    }
}
